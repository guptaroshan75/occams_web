// import React from "react";

// const PeoplePriorities = () => {
//     return (
//         <div className="bg-[#F7F7F7] lg:px-14 md:px-8 px-7 lg:py-7 md:py-7 py-6">
//             <div className="text-center max-w-3xl mx-auto lg:mb-10 mb-6" data-aos="zoom-in">
//                 <h2 className="lg:text-4xl text-2xl font-bold text-center linear-text-gradient">
//                     Our People Priorities
//                 </h2>

//                 <p className="lg:text-xl md:text-lg sm:text-base text-sm">
//                     Here’s what we focus on to make Occams a place where people thrive
//                 </p>
//             </div>

//             <div className="grid grid-cols-1 md:grid-cols-12 lg:gap-8 md:gap-6 gap-5 items-center">
//                 <div className="md:col-span-6 lg:col-span-5" data-aos="zoom-in">
//                     <img src="/assets/occams_edge.svg" alt="Occams Edge"
//                         className="w-full h-auto lg:rounded-none md:rounded-none rounded-xl"
//                     />
//                 </div>

//                 <div className="md:col-span-6 lg:col-span-7 max-w-3xl" data-aos="fade-right">
//                     <div className="lg:w-2/3 w-full lg:mb-12 md:mb-6 mb-4 font-semibold text-black">
//                         <h2 className="lg:text-4xl md:text-3xl sm:text-2xl text-base">
//                             Come build what’s next with us.
//                         </h2>
//                     </div>

//                     <h3 className="lg:text-3xl md:text-xl sm:text-2xl text-base 
//                         font-semibold text-black mb-1"
//                     >
//                         Celebrating our people-first culture:
//                     </h3>

//                     <p className="lg:text-lg md:text-lg sm:text-base text-sm">
//                         We’re proud to be recognized not only for business impact, but for building
//                         an exceptional workplace. Some of our recent accolades include:
//                     </p>
//                 </div>
//             </div>
//         </div>
//     )
// };

// export default PeoplePriorities;


const priorities = [
    {
        title: "Purpose",
        description: "Everyone should know why their work matters — to themselves, their team, and our business.",
        image: "/assets/purpose.png",
    },
    {
        title: "Lean Structure",
        description: "No layers for the sake of it. We keep things flat, efficient, & agile.",
        image: "/assets/lean_structure.png",
    },
    {
        title: "Always Learning",
        description: "Continuous learning is our default mode. We learn by doing, sharing, and improving continuously.",
        image: "/assets/always_learning.png",
        highlight: true,
    },
    {
        title: "Culture That Matters",
        description: "We move quickly, focus on value creation, keep our people at the center, and treat each other with respect and appreciation.",
        image: "/assets/culture_that.png",
    },
    {
        title: "Quick, Smart Decisions",
        description: "We act with a bias for action. We base decisions on data and facts, not just opinions.",
        image: "/assets/smart_decisions.png",
    },
    {
        title: "Connected Thinking",
        description: "We build partnerships across teams, functions, and ecosystems to help everyone succeed.",
        image: "/assets/connected_thinking.png",
    },
    {
        title: "Clear Focus",
        description: "We make sure people understand what’s most important and how they can contribute.",
        image: "/assets/clear_focus.png",
    },
    {
        title: "Talent Is Everything",
        description: "We invest in people, especially in the roles that matter most to our success.",
        image: "/assets/talent.png",
    },
    {
        title: "Technology with Purpose",
        description: "We treat data as a core business asset — it guides our decisions, our growth, and our innovation.",
        image: "/assets/technology.png",
    },
];

// const PeoplePriorities = () => {
//     const priorities = [
//         {
//             title: "Purpose",
//             description: "Everyone should know why their work matters — to themselves, their team, and our business.",
//             image: "/assets/purpose.png",
//             bgColor: "bg-blue-900",
//             textColor: "text-white",
//             colSpan: "col-span-3",
//             rowSpan: "row-span-2",
//             height: "h-96"
//         },
//         {
//             title: "Lean Structure",
//             description: "No layers for the sake of it. We keep things flat, efficient, & agile.",
//             image: "/assets/lean_structure.png",
//             bgColor: "bg-gray-800",
//             textColor: "text-white",
//             colSpan: "col-span-3",
//             height: "h-44"
//         },
//         {
//             title: "Always Learning",
//             description: "Continuous learning is our default mode. We learn by doing, sharing, and improving continuously.",
//             image: "/assets/always_learning.png",
//             bgColor: "bg-green-600",
//             textColor: "text-white",
//             colSpan: "col-span-3",
//             height: "h-44",
//             highlight: true
//         },
//         {
//             title: "Culture That Matters",
//             description: "We move quickly, focus on value creation, keep our people at the center, and treat each other with respect and appreciation.",
//             image: "/assets/culture_that.png",
//             bgColor: "bg-gray-700",
//             textColor: "text-white",
//             colSpan: "col-span-3",
//             height: "h-44"
//         },
//           {
//             title: "Connected Thinking",
//             description: "We build partnerships across teams, functions, and ecosystems to help everyone succeed.",
//             image: "/assets/connected_thinking.png",
//             bgColor: "bg-blue-100",
//             textColor: "text-gray-800",
//             colSpan: "col-span-3",
//             height: "h-28"
//         },
//         {
//             title: "Quick, Smart Decisions",
//             description: "We act with a bias for action. We base decisions on data and facts, not just opinions.",
//             image: "/assets/smart_decisions.png",
//             bgColor: "bg-gray-800",
//             textColor: "text-white",
//             colSpan: "col-span-3",
//             height: "h-44"
//         },
//         {
//             title: "Talent Is Everything",
//             description: "We invest in people, especially in the roles that matter most to our success.",
//             image: "/assets/talent.png",
//             bgColor: "bg-white",
//             textColor: "text-gray-800",
//             colSpan: "col-span-3",
//             height: "h-44",
//             border: "border border-gray-200 shadow-sm"
//         },
//         {
//             title: "Clear Focus",
//             description: "We make sure people understand what's most important and how they can contribute.",
//             image: "/assets/clear_focus.png",
//             bgColor: "bg-purple-900",
//             textColor: "text-white",
//             colSpan: "col-span-3",
//             rowSpan: "row-span-2",
//             height: "h-96"
//         },
//         {
//             title: "Technology with Purpose",
//             description: "We treat data as a core business asset — it guides our decisions, our growth, and our innovation.",
//             image: "/assets/technology.png",
//             bgColor: "bg-blue-400",
//             textColor: "text-white",
//             colSpan: "col-span-6",
//             height: "h-44"
//         }
//     ];

//     return (
//         <div className="bg-gray-50 py-16 px-4">
//             <div className="max-w-7xl mx-auto">
//                 {/* Header */}
//                 <div className="text-center mb-12">
//                     <h2 className="text-4xl font-bold text-orange-500 mb-4">Our People Priorities</h2>
//                     <p className="text-lg text-gray-700 max-w-2xl mx-auto">
//                         Here's what we focus on to make Occams a place where people thrive
//                     </p>
//                 </div>

//                 {/* Masonry Grid Layout */}
//                 <div className="grid grid-cols-12 gap-4 auto-rows-min">
//                     {priorities.map((priority, index) => (
//                         <div key={index} className={`${priority.colSpan} ${priority.rowSpan || ''}`}>
//                             <div className={` rounded-2xl p-6 ${priority.height} relative overflow-hidden`}>
//                                 {/* Image Container */}
//                                 <div className="absolute right-4 top-4">
//                                     {/* <div className={`${priority.height === 'h-28' ? 'w-12 h-12' : priority.height === 'h-96' ? 'w-20 h-20' : 'w-16 h-16'} bg-white/10 rounded-lg flex items-center justify-center overflow-hidden`}> */}
//                                         <img
//                                             src={priority.image}
//                                             alt={priority.title}
//                                             className="w-full h-full object-cover"
//                                             onError={(e) => {
//                                                 // Fallback if image doesn't load
//                                                 e.target.style.display = 'none';
//                                                 e.target.parentNode.innerHTML = `<div class="text-xl ${priority.textColor === 'text-white' ? 'text-white' : 'text-gray-400'}"></div>`;
//                                             }}
//                                         />
//                                     {/* </div> */}
//                                 </div>

//                                 {/* Content */}
//                                 <div className="relative z-10 h-full flex flex-col justify-end">
//                                     <h3 className={`${priority.height === 'h-96' ? 'text-2xl' : priority.height === 'h-28' ? 'text-lg' : 'text-xl'} font-bold ${priority.height === 'h-28' ? 'mb-1' : priority.height === 'h-96' ? 'mb-3' : 'mb-2'}`}>
//                                         {priority.title}
//                                     </h3>
//                                     <p className={`${priority.height === 'h-28' ? 'text-xs' : 'text-sm'} ${priority.textColor === 'text-white' ? 'opacity-90' : 'opacity-80'}`}>
//                                         {priority.description}
//                                     </p>
//                                 </div>
//                             </div>
//                         </div>
//                     ))}
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default PeoplePriorities;

const PeoplePriorities = () => {
    const priorities = [
        {
            title: "Purpose",
            description: "Everyone should know why their work matters — to themselves, their team, and our business.",
            image: "/assets/purpose.png",
            bgColor: "bg-blue-900",
            textColor: "text-white",
            // Responsive grid spans
            colSpan: "col-span-12 sm:col-span-6 lg:col-span-3",
            rowSpan: "lg:row-span-2",
            height: "h-64 sm:h-80 lg:h-[32rem]", // Much thicker
            isLarge: true
        },
        {
            title: "Lean Structure",
            description: "No layers for the sake of it. We keep things flat, efficient, & agile.",
            image: "/assets/lean_structure.png",
            bgColor: "bg-gray-800",
            textColor: "text-white",
            colSpan: "col-span-12 sm:col-span-6 lg:col-span-3",
            height: "h-56 sm:h-64 lg:h-72" // Thicker
        },
        {
            title: "Always Learning",
            description: "Continuous learning is our default mode. We learn by doing, sharing, and improving continuously.",
            image: "/assets/always_learning.png",
            bgColor: "bg-green-600",
            textColor: "text-white",
            colSpan: "col-span-12 sm:col-span-6 lg:col-span-3",
            height: "h-56 sm:h-64 lg:h-72", // Thicker
            highlight: true
        },
        {
            title: "Culture That Matters",
            description: "We move quickly, focus on value creation, keep our people at the center, and treat each other with respect and appreciation.",
            image: "/assets/culture_that.png",
            bgColor: "bg-gray-700",
            textColor: "text-white",
            colSpan: "col-span-12 sm:col-span-6 lg:col-span-3",
            height: "h-56 sm:h-64 lg:h-72" // Thicker
        },
        {
            title: "Connected Thinking",
            description: "We build partnerships across teams, functions, and ecosystems to help everyone succeed.",
            image: "/assets/connected_thinking.png",
            bgColor: "bg-blue-100",
            textColor: "text-gray-800",
            colSpan: "col-span-12 sm:col-span-6 lg:col-span-3",
            height: "h-48 sm:h-52 lg:h-56" // Thicker
        },
        {
            title: "Quick, Smart Decisions",
            description: "We act with a bias for action. We base decisions on data and facts, not just opinions.",
            image: "/assets/smart_decisions.png",
            bgColor: "bg-gray-800",
            textColor: "text-white",
            colSpan: "col-span-12 sm:col-span-6 lg:col-span-3",
            height: "h-56 sm:h-64 lg:h-72" // Thicker
        },
        {
            title: "Talent Is Everything",
            description: "We invest in people, especially in the roles that matter most to our success.",
            image: "/assets/talent.png",
            bgColor: "bg-white",
            textColor: "text-gray-800",
            colSpan: "col-span-12 sm:col-span-6 lg:col-span-3",
            height: "h-56 sm:h-64 lg:h-72", // Thicker
            border: "border border-gray-200 shadow-lg"
        },
        {
            title: "Clear Focus",
            description: "We make sure people understand what's most important and how they can contribute.",
            image: "/assets/clear_focus.png",
            bgColor: "bg-purple-900",
            textColor: "text-white",
            colSpan: "col-span-12 sm:col-span-6 lg:col-span-3",
            rowSpan: "lg:row-span-2",
            height: "h-64 sm:h-80 lg:h-[32rem]", // Much thicker
            isLarge: true
        },
        {
            title: "Technology with Purpose",
            description: "We treat data as a core business asset — it guides our decisions, our growth, and our innovation.",
            image: "/assets/technology.png",
            bgColor: "bg-blue-400",
            textColor: "text-white",
            colSpan: "col-span-12 lg:col-span-6",
            height: "h-56 sm:h-64 lg:h-72" // Thicker
        }
    ];

    return (
        <div className="bg-gray-50 py-12 sm:py-16 lg:py-20 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="text-center mb-8 sm:mb-12 lg:mb-16">
                    <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-orange-500 mb-4 lg:mb-6">
                        Our People Priorities
                    </h2>
                    <p className="text-base sm:text-lg lg:text-xl text-gray-700 max-w-2xl lg:max-w-3xl mx-auto leading-relaxed">
                        Here's what we focus on to make Occams a place where people thrive
                    </p>
                </div>

                {/* Responsive Grid Layout */}
                <div className="grid grid-cols-12 gap-4 sm:gap-6 lg:gap-8 auto-rows-min">
                    {priorities.map((priority, index) => (
                        <div key={index} className={`${priority.colSpan} ${priority.rowSpan || ''}`}>
                            <div className={` ${priority.border || ''} rounded-2xl sm:rounded-3xl p-6 sm:p-8 lg:p-10 ${priority.height} relative overflow-hidden`}>
                                {/* Image Container */}
                                <div className="absolute right-4 sm:right-6 lg:right-8 top-4 sm:top-6 lg:top-8">
                                        <img 
                                            src={priority.image} 
                                            alt={priority.title}
                                            className="w-full h-full object-cover"
                                            onError={(e) => {
                                                e.target.style.display = 'none';
                                                e.target.parentNode.innerHTML = `<div class="text-xl sm:text-2xl"></div>`;
                                            }}
                                        />
                                </div>

                                {/* Content */}
                                <div className="relative z-10 h-full flex flex-col">
                                    <h3 className={`${
                                        priority.isLarge 
                                            ? 'text-xl sm:text-2xl lg:text-3xl xl:text-4xl mb-3 sm:mb-4 lg:mb-6' 
                                            : 'text-lg sm:text-xl lg:text-2xl mb-2 sm:mb-3 lg:mb-4'
                                    } font-bold leading-tight`}>
                                        {priority.title}
                                    </h3>
                                    <p className={`${
                                        priority.isLarge 
                                            ? 'text-sm sm:text-base lg:text-lg' 
                                            : 'text-xs sm:text-sm lg:text-base'
                                    } ${priority.textColor === 'text-white' ? 'opacity-90' : 'opacity-80'} leading-relaxed max-w-lg`}>
                                        {priority.description}
                                    </p>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default PeoplePriorities;