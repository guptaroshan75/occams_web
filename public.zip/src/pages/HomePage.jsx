import { Fragment } from 'react';
import Banner from '../Components/Banner';
import AboutUs from './AboutUs';
import Resources from './Resources';
import Awards from './Awards';
import WorkAtOccams from '../components/WorkAtOccams';
import PeoplePriorities from './PeoplePriorities';

const HomePage = () => {

    return (
        <Fragment>
            <Banner />
            <AboutUs />
            <PeoplePriorities />
            <Resources />
            <Awards />
            <WorkAtOccams />
        </Fragment>
    )
}

export default HomePage


// import { Fragment, useState, useRef, useEffect } from 'react';
// import Banner from '../Components/Banner';
// import AboutUs from './AboutUs';
// import Resources from './Resources';
// import Awards from './Awards';
// import WorkAtOccams from '../components/WorkAtOccams';
// import PeoplePriorities from './PeoplePriorities';
// import { GiShare } from 'react-icons/gi';
// import { GoBookmark } from 'react-icons/go';

// const tabs = [
//   { label: "The HCMI North Star", id: "hcmi" },
//   { label: "Our people priorities", id: "priorities" },
//   { label: "The occams edge", id: "edge" },
//   { label: "Working at Occams", id: "working" },
// ];

// const HomePage = () => {
//   const [activeTab, setActiveTab] = useState(tabs[0].label);
//   const [underlineStyle, setUnderlineStyle] = useState({ left: 0, width: 0 });
//   const tabRefs = useRef([]);
//   const sectionRefs = useRef({});

//   // Set section refs
//   useEffect(() => {
//     tabs.forEach(tab => {
//       sectionRefs.current[tab.id] = document.getElementById(tab.id);
//     });
//     // Position underline initially
//     updateUnderline(tabs[0].label);
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, []);

//   // Position the underline under the given tab
//   const updateUnderline = (label) => {
//     const index = tabs.findIndex(t => t.label === label);
//     const el = tabRefs.current[index];
//     if (el) {
//       const rect = el.getBoundingClientRect();
//       const parentRect = el.parentNode.getBoundingClientRect();
//       setUnderlineStyle({ left: rect.left - parentRect.left, width: rect.width });
//     }
//   };

//   // Handle clicks
//   const handleClick = (tab, idx) => {
//     const sec = sectionRefs.current[tab.id];
//     if (sec) {
//       sec.scrollIntoView({ behavior: 'smooth', block: 'start' });
//     }
//     setActiveTab(tab.label);
//     updateUnderline(tab.label);
//   };

//   // Observe scrolling
//   useEffect(() => {
//     const observer = new IntersectionObserver(entries => {
//       // Find the section with the largest intersection area > 10%
//       const visible = entries
//         .filter(e => e.intersectionRatio > 0.1)
//         .sort((a, b) => b.intersectionRatio - a.intersectionRatio);

//       if (visible.length > 0) {
//         const currentId = visible[0].target.id;
//         const tab = tabs.find(t => t.id === currentId);
//         if (tab && tab.label !== activeTab) {
//           setActiveTab(tab.label);
//           updateUnderline(tab.label);
//         }
//       }
//     }, {
//       root: null,
//       rootMargin: '0px',
//       threshold: Array.from({ length: 11 }, (_, i) => i * 0.1), // 0,10,20,…100%
//     });

//     tabs.forEach(tab => {
//       const sec = sectionRefs.current[tab.id];
//       if (sec) observer.observe(sec);
//     });

//     return () => observer.disconnect();
//   }, [activeTab]);

//   return (
//     <Fragment>
//       <Banner />

//       <div className="sticky top-[82px] z-50 bg-white shadow-sm border-t border-[#D3D3D3]">
//         <div className="lg:px-14 md:px-8 px-7 border-b border-[#A6A6A6] flex justify-between">
//           <div className="relative flex gap-5 overflow-x-auto whitespace-nowrap scroll-smooth">
//             {tabs.map((tab, idx) => (
//               <button
//                 key={tab.id}
//                 ref={el => (tabRefs.current[idx] = el)}
//                 onClick={() => handleClick(tab, idx)}
//                 className={`py-3 text-sm md:text-base text-black cursor-pointer ${
//                   activeTab === tab.label ? 'font-semibold' : ''
//                 }`}
//               >
//                 {tab.label}
//               </button>
//             ))}

//             <span
//               className="absolute bottom-0 h-[3.5px] bg-[#F36B21] rounded-[3.5px] transition-all duration-300 ease-in-out"
//               style={{ left: underlineStyle.left, width: underlineStyle.width }}
//             />
//           </div>

//           <div className="hidden md:flex items-center gap-4 text-lg cursor-pointer">
//             <GiShare />
//             <GoBookmark />
//           </div>
//         </div>
//       </div>

//       <section id="hcmi"><AboutUs /></section>

//       <section id="priorities" className="min-h-[300px] py-10">
//         <PeoplePriorities />
//       </section>

//       <section id="edge">
//         <Resources />
//         <Awards />
//       </section>

//       <section id="working"><WorkAtOccams /></section>
//     </Fragment>
//   );
// };

// export default HomePage;

// import { Fragment, useState, useRef, useEffect } from 'react';
// import Banner from '../Components/Banner';
// import AboutUs from './AboutUs';
// import Resources from './Resources';
// import Awards from './Awards';
// import WorkAtOccams from '../components/WorkAtOccams';
// import PeoplePriorities from './PeoplePriorities';
// import { GiShare } from 'react-icons/gi';
// import { GoBookmark } from 'react-icons/go';

// const tabs = [
//     { label: "The HCMI North Star", id: "hcmi" },
//     { label: "Our people priorities", id: "priorities" },
//     { label: "The occams edge", id: "edge" },
//     { label: "Working at Occams", id: "working" },
// ];

// const HomePage = () => {
//     const [activeTab, setActiveTab] = useState(tabs[0].label);
//     const tabRefs = useRef([]);
//     const sectionRefs = useRef({});
//     const underlineRef = useRef(null);

//     // Set section refs on mount
//     useEffect(() => {
//         tabs.forEach(tab => {
//             sectionRefs.current[tab.id] = document.getElementById(tab.id);
//         });
//         updateUnderline(tabs[0].label); // Initialize underline
//     }, []);

//     const handleClick = (tab, index) => {
//         const section = sectionRefs.current[tab.id];
//         if (section) {
//             section.scrollIntoView({ behavior: 'smooth', block: 'start' });
//         }
//         setActiveTab(tab.label);
//         updateUnderline(tab.label);
//     };

//     const updateUnderline = (label) => {
//         const index = tabs.findIndex(t => t.label === label);
//         const el = tabRefs.current[index];
//         if (el && underlineRef.current) {
//             const rect = el.getBoundingClientRect();
//             const parentRect = el.parentElement.getBoundingClientRect();
//             underlineRef.current.style.left = `${rect.left - parentRect.left}px`;
//             underlineRef.current.style.width = `${rect.width}px`;
//         }
//     };

//     // Observe sections in view
//     useEffect(() => {
//         const observer = new IntersectionObserver(
//             (entries) => {
//                 const visible = entries
//                     .filter(e => e.intersectionRatio > 0.1)
//                     .sort((a, b) => b.intersectionRatio - a.intersectionRatio);

//                 if (visible.length > 0) {
//                     const currentId = visible[0].target.id;
//                     const tab = tabs.find(t => t.id === currentId);
//                     if (tab && tab.label !== activeTab) {
//                         setActiveTab(tab.label);
//                         updateUnderline(tab.label);
//                     }
//                 }
//             },
//             {
//                 threshold: Array.from({ length: 11 }, (_, i) => i * 0.1),
//             }
//         );

//         tabs.forEach(tab => {
//             const section = sectionRefs.current[tab.id];
//             if (section) observer.observe(section);
//         });

//         return () => observer.disconnect();
//     }, [activeTab]);

//     return (
//         <Fragment>
//             <Banner />

//             <div className="sticky lg:top-[82px] md:top-[82px] sm:top-0 z-50 bg-white shadow-sm border-t border-[#D3D3D3]">
//                 <div className="lg:px-14 md:px-8 px-7 border-b border-[#A6A6A6] flex justify-between">
//                     <div className="relative w-full">
//                         <div className="flex gap-5 overflow-x-auto whitespace-nowrap scroll-smooth no-scrollbar service-lp-tab relative">
//                             {tabs.map((tab, idx) => (
//                                 <button
//                                     key={tab.id}
//                                     ref={(el) => (tabRefs.current[idx] = el)}
//                                     onClick={() => handleClick(tab, idx)}
//                                     className={`cursor-pointer relative py-3 px-1 text-sm md:text-base text-black whitespace-nowrap ${
//                                         activeTab === tab.label ? 'font-semibold' : ''
//                                     }`}
//                                 >
//                                     {tab.label}
//                                 </button>
//                             ))}
//                             <span
//                                 ref={underlineRef}
//                                 className="absolute bottom-0 h-[3px] bg-[#F36B21] rounded-[3px] transition-all duration-300 ease-in-out"
//                                 style={{ left: 0, width: 0 }}
//                             />
//                         </div>
//                     </div>

//                     <div className="hidden md:flex items-center gap-4 text-lg cursor-pointer">
//                         <GiShare />
//                         <GoBookmark />
//                     </div>
//                 </div>
//             </div>

//             {/* Sections */}
//             <section id="hcmi"><AboutUs /></section>

//             <section id="priorities" className="min-h-[300px] py-10">
//                 <PeoplePriorities />
//             </section>

//             <section id="edge">
//                 <Resources />
//                 <Awards />
//             </section>

//             <section id="working"><WorkAtOccams /></section>
//         </Fragment>
//     );
// };

// export default HomePage;

